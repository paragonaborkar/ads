CREATE PROCEDURE sp_activity_migrate(IN migrateWeek DATETIME)
  BEGIN
		INSERT INTO vitae_data.migration
		(migrate_week, migrate_day, migrate_time, ao_stdid, applicationName, lob, src_contId, src_vFilerName, src_aggrId, src_volName, 
			src_volId, src_qtreeId, src_datacenterId, tgt_storageId, tgt_volName, tgt_vol_size)
		SELECT
			vitae_data.activity.migrate_week,
			vitae_data.activity.migrate_day,
			vitae_data.activity.migrate_time,
			IFNULL(vitae_data.activity.owner_actual_stdid, 'Z999998') as owner_actual_stdid,
			IFNULL(vitae_data.activity.app_name_list, 'unknown') as app_name_list,
            IFNULL(vitae_data.activity.lob_presumed,'orphan'),
			vitae_data.controller.id as srcContId, 
			vitae_data.activity.vServer,
			vitae_data.activity.aggrId,
			vitae_data.activity.vol_name as src_volName,
			vitae_data.activity.intVolId,
			vitae_data.qtree.id qtreeId,
			vitae_data.datacenter.id as datacenterId,
            vitae_data.cycle.targetClusterId,
            CONCAT(vitae_data.storage.name, 'p_',LCASE(vitae_data.activity.lob_presumed), '_sub_',LCASE(REPLACE(vitae_data.activity.app_name_list,' ','')),'_prd'),
            CASE
				WHEN vitae_data.qtree.quotaHardCapacityLimitMB IS NULL AND vitae_data.qtree.quotaSoftCapacityLimitMB IS NULL AND vitae_data.qtree.quotaUsedCapacityMB IS NULL
					THEN IF(vitae_data.volume.allocCap > 10,vitae_data.volume.allocCap,10)
                WHEN vitae_data.qtree.quotaHardCapacityLimitMB IS NULL AND vitae_data.qtree.quotaSoftCapacityLimitMB IS NULL 
					THEN IF(vitae_data.qtree.quotaUsedCapacityMB > 10,vitae_data.qtree.quotaUsedCapacityMB,10)
				WHEN vitae_data.qtree.quotaHardCapacityLimitMB > vitae_data.qtree.quotaSoftCapacityLimitMB 
					THEN IF(vitae_data.qtree.quotaHardCapacityLimitMB/1024 > 10, CEIL(vitae_data.qtree.quotaHardCapacityLimitMB/1024), 10)
				WHEN vitae_data.qtree.quotaSoftCapacityLimitMB > vitae_data.qtree.quotaHardCapacityLimitMB 
					THEN IF(vitae_data.qtree.quotaSoftCapacityLimitMB/1024 > 10, CEIL(vitae_data.qtree.quotaSoftCapacityLimitMB/1024), 10)
				ELSE 10
            END 

		FROM vitae_data.activity 
		
        LEFT JOIN vitae_data.qtree 
			ON vitae_data.activity.intVolId = vitae_data.qtree.internalVolumeId
		
        JOIN vitae_data.volume
			ON vitae_data.activity.intVolId = vitae_data.volume.intVolId

		LEFT JOIN vitae_data.controller 
			ON vitae_data.activity.ctrl_name = vitae_data.controller.controllerName

		LEFT JOIN vitae_data.datacenter 
			ON vitae_data.controller.datacenter = vitae_data.datacenter.name
		
        JOIN vitae_data.cycle
			ON vitae_data.controller.controllerName = vitae_data.cycle.controllerName
		JOIN vitae_data.storage
			ON vitae_data.cycle.targetClusterId = vitae_data.storage.id

		WHERE activity.migrate_week = migrateWeek AND 
			vitae_data.qtree.id NOT IN 
				(SELECT id from vitae_data.qtree 
				GROUP BY vitae_data.qtree.internalVolumeId
				HAVING COUNT(vitae_data.qtree.internalVolumeId) > 1 AND vitae_data.qtree.name = '-')
;

END;

