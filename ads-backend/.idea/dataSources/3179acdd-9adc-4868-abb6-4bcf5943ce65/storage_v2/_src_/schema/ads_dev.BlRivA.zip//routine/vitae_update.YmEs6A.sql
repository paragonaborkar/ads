CREATE PROCEDURE vitae_update()
  BEGIN
INSERT INTO vitae_data.datacenter
	(name,region,create_date,creation_user)
	SELECT DISTINCT 
		dwh_inventory.storage.datacenter,
		dwh_inventory.storage.Region,
		NOW(),
		'system'
		
	FROM dwh_inventory.storage
	
	ON DUPLICATE KEY UPDATE 
        last_upd_dt=NOW(),
        last_upd_user='system';

INSERT INTO vitae_data.storage 
	(id,name,model,family,manufacturer,serialNumber,microcodeVersion,rawCapacityMB,datacenter,region,create_date,creation_user)
	
    SELECT 
		dwh_inventory.storage.id,
		dwh_inventory.storage.name,
		dwh_inventory.storage.model,
		dwh_inventory.storage.family,
		dwh_inventory.storage.manufacturer,
		dwh_inventory.storage.serialNumber,
		dwh_inventory.storage.microcodeVersion,
		dwh_inventory.storage.rawCapacityMB,
		dwh_inventory.storage.datacenter,
		dwh_inventory.storage.region,
		NOW(),
		'system'
    
    FROM dwh_inventory.storage
    
    ON DUPLICATE KEY UPDATE 
    	name=VALUES(name),
    	model=VALUES(model),
    	family=VALUES(family),
    	manufacturer = VALUES(manufacturer),
    	serialNumber= VALUES(serialNumber),
    	microcodeVersion = VALUES(microcodeVersion),
    	rawCapacityMB =VALUES(rawCapacityMB),
    	datacenter = VALUES(datacenter),
    	region = VALUES(region),
        last_upd_dt=NOW(),
        last_upd_user='system'
;	
	
INSERT INTO `vitae_data`.`controller` 
	(id, controllerName,serialNumber, storageId, storageName, model, datacenter, dateAvail, volumeCount,create_date,creation_user)
    SELECT 
		dwh_inventory.storage_node.id,
        dwh_inventory.storage_node.name,
        dwh_inventory.storage_node.serialNumber,
        dwh_inventory.storage_node.storageId,
        dwh_inventory.storage.name,        
        dwh_inventory.storage_node.model,
        dwh_inventory.storage.dataCenter,
        DATE(NOW()),
        COUNT(DISTINCT dwh_inventory.internal_volume.id),
        NOW(),
        'system'
	FROM dwh_inventory.storage_node
    
    JOIN dwh_inventory.storage
		ON dwh_inventory.storage.id = dwh_inventory.storage_node.storageId
        
	JOIN dwh_inventory.storage_node_to_internal_volume
		ON dwh_inventory.storage_node.id = dwh_inventory.storage_node_to_internal_volume.storageNodeId
	
    JOIN dwh_inventory.internal_volume
		ON dwh_inventory.storage_node_to_internal_volume.internalVolumeId = dwh_inventory.internal_volume.id
	
    
    GROUP BY dwh_inventory.storage_node.id
    
    ON DUPLICATE KEY UPDATE 
    	controllerName = VALUES(controllerName),
        serialNumber = VALUES(serialNumber),
        storageId = VALUES(storageId),
        storageName = VALUES(storageName),
        model = VALUES(model),
        datacenter = VALUES(datacenter),
        last_upd_dt=NOW(),
        last_upd_user='system'
 ;
 
 INSERT INTO vitae_data.aggregate
	(id, name, storage_id, size, isHybrid, type, controller_id, poolAllocatedCapMB, poolUsedCapMB, poolIopsCapability, avgIOpS, peakIOpS, create_date,creation_user)
    SELECT 
		dwh_inventory.storage_pool.id,
		IF (dwh_inventory.storage_pool.name LIKE '%:%',
			SUBSTRING_INDEX(dwh_inventory.storage_pool.name,':',-1),
			dwh_inventory.storage_pool.name),
		dwh_inventory.storage_pool.storageId,
		dwh_inventory.storage_pool.totalAllocatedCapacityMB,
		dwh_inventory.storage_pool.usesFlashPools,
		dwh_inventory.storage_pool.type,
		dwh_inventory.storage_node_to_storage_pool.storageNodeId,
        dwh_inventory.wcr_pool_combined_data.poolAllocatedCapMB,
        dwh_inventory.wcr_pool_combined_data.poolUsedCapMB,
        dwh_inventory.wcr_pool_combined_data.poolIopsCapability,
        dwh_inventory.wcr_pool_combined_data.avgIOpS,
        dwh_inventory.wcr_pool_combined_data.maxIOpS,
        NOW(),
        'system'
    
	FROM dwh_inventory.storage_pool

	JOIN dwh_inventory.storage_node_to_storage_pool
		ON dwh_inventory.storage_pool.id = dwh_inventory.storage_node_to_storage_pool.storagePoolId
        
	LEFT JOIN dwh_inventory.wcr_pool_combined_data
		ON dwh_inventory.storage_pool.id = dwh_inventory.wcr_pool_combined_data.storagePoolId
	
	ON DUPLICATE KEY UPDATE 
		name = VALUES(name),
		storage_id = VALUES(storage_id),
		size = VALUES(size),
		poolAllocatedCapMB = VALUES(poolAllocatedCapMB), 
        poolUsedCapMB = VALUES(poolUsedCapMB), 
        poolIopsCapability = VALUES(poolIopsCapability), 
        avgIOpS = VALUES(avgIOpS), 
        peakIOpS = VALUES(peakIOpS),
        last_upd_dt=NOW(),
        last_upd_user='system'
;

INSERT INTO vitae_data.volume
	(intVolId, contId, aggrId, vServer,volName, allocCap, usedCap, snapType, snapSrcVolId, snapTgtVolId, snap_count,
		status, lastAccess, avgIOpS, peakIOpS, create_date,creation_user)
    SELECT
		volSel.intVolId, 
		volSel.contId, 
		volSel.aggrId, 
		volSel.vServer,
        volSel.volName, 
        volSel.allocCap, 
        volSel.usedCap, 
        volSel.snapType, 
        volSel.snapSrcVolId, 
        volSel.snapTgtVolId, 
        volSel.snap_count,
		volSel.status, 
        volSel.lastAccess, 
        volSel.avgIOpS, 
        volSel.peakIOpS, 
        volSel.create_date,
        volSel.creation_user
    FROM 
    (SELECT DISTINCT
		dwh_inventory.internal_volume.id AS 'intVolId',
        dwh_inventory.storage_node_to_storage_pool.storageNodeId AS 'contId',
        dwh_inventory.internal_volume.storagePoolId AS 'aggrId',
        IF (dwh_inventory.internal_volume.virtualStorage IS NULL, 'vFiler0',
			dwh_inventory.internal_volume.virtualStorage) AS 'vServer',
        IF (dwh_inventory.internal_volume.name LIKE '%:%',
			SUBSTRING_INDEX(dwh_inventory.internal_volume.name,':',-1),
			dwh_inventory.internal_volume.name) AS 'volName',
		dwh_inventory.internal_volume.totalAllocatedCapacityMB/1024 AS 'allocCap',
        dwh_inventory.internal_volume.totalUsedCapacityMB/1024 AS 'usedCap',
        dwh_inventory.dr_internal_volume_replica.technology AS 'snapType',
        dwh_inventory.dr_internal_volume_replica.sourceInternalVolumeId AS 'snapSrcVolId',
        dwh_inventory.dr_internal_volume_replica.targetInternalVolumeId AS 'snapTgtVolId',
        dwh_inventory.internal_volume.snapshotCount AS 'snap_count',
        dwh_inventory.internal_volume.status AS 'status',
        MAX(dwh_inventory.wcr_host_conn_view.lastSeen) AS 'lastAccess',
        dwh_inventory.wcr_vol_combined_data.avgIOpS AS 'avgIOpS',
        dwh_inventory.wcr_vol_combined_data.peakIOpS AS 'peakIOpS',
        NOW() AS 'create_date',
        'system' AS 'creation_user'
        
	FROM dwh_inventory.internal_volume
    
	JOIN dwh_inventory.storage_node_to_storage_pool
		ON dwh_inventory.internal_volume.storagePoolId = dwh_inventory.storage_node_to_storage_pool.storagePoolId
        
	LEFT JOIN dwh_inventory.dr_internal_volume_replica
		ON dwh_inventory.internal_volume.id = dwh_inventory.dr_internal_volume_replica.sourceInternalVolumeId
	
    LEFT JOIN dwh_inventory.wcr_host_conn_view
		ON dwh_inventory.internal_volume.id = dwh_inventory.wcr_host_conn_view.intVolId
        
	LEFT JOIN dwh_inventory.wcr_volume_dimension
		ON dwh_inventory.internal_volume.id = dwh_inventory.wcr_volume_dimension.internalVolumeId
        
	LEFT JOIN dwh_inventory.wcr_vol_combined_data
		ON dwh_inventory.wcr_volume_dimension.id = dwh_inventory.wcr_vol_combined_data.volDimId
	
    WHERE dwh_inventory.internal_volume.id NOT IN (SELECT targetInternalVolumeId FROM dwh_inventory.dr_internal_volume_replica) 
    
	GROUP BY dwh_inventory.internal_volume.id  ) AS volSel
	
    ON DUPLICATE KEY UPDATE 
		allocCap = VALUES(allocCap),
        usedCap = VALUES(usedCap),
        lastAccess = VALUES(lastAccess),
        avgIOpS = VALUES(avgIOpS),
        peakIOpS = VALUES(peakIOpS),
        last_upd_dt=NOW(),
        last_upd_user='system'
;
         

INSERT INTO vitae_data.host
	(hostname,ipAddress,create_date,creation_user)
	SELECT
        dwh_inventory.wcr_host_conn_view.hostname,
        dwh_inventory.wcr_host_conn_view.ip,
        NOW(),
        'system'
	FROM dwh_inventory.wcr_host_conn_view
    
    ON DUPLICATE KEY UPDATE 
        last_upd_dt=NOW(),
        last_upd_user='system'
;


INSERT INTO vitae_data.share
	(shareId, name, volumeId, shareType, hostId,qtreeId,create_date,creation_user)
    SELECT 
		dwh_inventory.nas_share.id,
		dwh_inventory.nas_share.name,
		dwh_inventory.nas_file_share.internalVolumeId,
		dwh_inventory.nas_share.protocol,
		vitae_data.host.id,
		dwh_inventory.nas_file_share.qtreeId,
        NOW(),
        'system'
    
	FROM dwh_inventory.nas_share
    
	JOIN dwh_inventory.nas_file_share
		ON dwh_inventory.nas_share.fileShareId = dwh_inventory.nas_file_share.id
        
	LEFT JOIN dwh_inventory.wcr_host_conn_view whcv
		ON dwh_inventory.nas_share.id = whcv.shareId 
            
	LEFT JOIN vitae_data.host
		ON whcv.ip = vitae_data.host.ipAddress
        
	ON DUPLICATE KEY UPDATE 
        last_upd_dt=NOW(),
        last_upd_user='system'
;

INSERT INTO vitae_data.qtree
	(id,internalVolumeId,name,quotaHardCapacityLimitMB,quotaSoftCapacityLimitMB,quotaUsedCapacityMB,type,securityStyle,status,create_date,creation_user) 
	
    SELECT dwh_inventory.qtree.id,
		dwh_inventory.qtree.internalVolumeId,
		dwh_inventory.qtree.name,
		dwh_inventory.qtree.quotaHardCapacityLimitMB,
		dwh_inventory.qtree.quotaSoftCapacityLimitMB,
		dwh_inventory.qtree.quotaUsedCapacityMB,
		dwh_inventory.qtree.type,
		dwh_inventory.qtree.securityStyle,
		dwh_inventory.qtree.status,
        NOW(),
        'system'
	FROM dwh_inventory.qtree
	
	JOIN dwh_inventory.nas_file_share
	ON dwh_inventory.nas_file_share.qtreeid = dwh_inventory.qtree.id
    
    JOIN dwh_inventory.nas_share
	ON dwh_inventory.nas_share.fileshareid = dwh_inventory.nas_file_share.id
    
    ON DUPLICATE KEY UPDATE
		quotaHardCapacityLimitMB = VALUES(quotaHardCapacityLimitMB),
        quotaSoftCapacityLimitMB = VALUES(quotaSoftCapacityLimitMB),
		quotaUsedCapacityMB = VALUES(quotaUsedCapacityMB),
        last_upd_dt=NOW(),
        last_upd_user='system'
	;

END;

